# CLCO App

Demo app for the Cloud Computing course at UAS Technikum Wien.

Raise questions and issues at `daniel.melichar@technikum-wien.at`
